#include <iostream>

// #include "stackint.h"
// #include "stackint.cpp"
// #include "drive_stackint.cpp"

#include "stackar.h"
#include "drive_stackar.cpp"

main() {
  drive_stackar();

  std::cout << "/* message */" << std::endl;

  return EXIT_SUCCESS;
}
