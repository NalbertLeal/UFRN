  # Atividade de implementação do Dicionário

  ### tópicos abordados:
  
- A implementação;
- Testes realizados;
- Bugs;
- Observações;
- Sobre mim;

  #### A implementação:
  
  A implentação do codigo não esta completamente finalizada, isso ocorreu pois na parte 4 ocorreram erros de ultima hora que não soube como corrigilos (no topico bugs falarei mais disso). Mesmo com o não termino da parte 4 creio ter chegado ao objetivo da ideia desse trabalho, compreender o funcionamento de uma TAD dicionário.  
  Obs.: Mesmo com o erro da parte 4 da atividade estou enviando o que implementei na parte problematica para caso aja duvidas do que foi feito, esse codigo foi colocado dentro da pasta TENTATIVA_PARTE4 e esta organizado como um projeto padrão.
  
  ### Testes realizados:
  
  Os testes realizados foram simples mas provavelmete foram o suficientes para mostrar que o dicionario possui os requisitos das partes 1, 2 e 3 da atividade. Para refaze-los basta abrir o arquivo src/main.cpp (ele contém o main do trabalho) nele você pode ver que existe um codigo comentado e outro não, esses são os 2 testes realizados, escolha qual rodar e compile o codigo para seu sistema operacional (o codigo ja encontra-se compilado para Debian na pasta bin).
  
  ### Bugs:
  
  Os principais bugs são:
  - O codigo da função compare(Key _x, Key _y) que realizaria a comparação dos dados na 4 parte do trabalho apresentou erro após a compilação imposibilitando que a atividade seja finalizada;
  - os métodos min(), max(), sucessor() e predecessor() por algum(ns) motivo(os) desconhecido(os) não estão sendo reconhecidos pelas classes DAL() e DSAL(), ouve inúmeras tentativas de consertar esse problema mas sem sucesso ate o momento do envio;
  - Se os métodos forem declarados fora das classes o código é rejeitado pelo compilador g++;
  

### Observações:
    
O trabalho não foi finalizado e por isso irei postalo em meu git hub para novas tentativas de conserta-lo. Até o dia 16/04/2016 acredito que todos os codigos das atividades já realizadas em LP1 e EDB1 vão estar disponiveis em repositorios para o caso de ouver interese de averiguação se ouve novas tentativas de minha parte para correção dos bugs citados acima.
    
### Sobre mim:
    
- Aluno: Nalbert Gabriel Melo Leal ;
- GitHub: nalbertg ;
- email pessoal: nalbertrn@yahoo.com.br ;
- email acadêmico/profissional: nalbertg@outlook.com ;
    
  